<?php
if(isset($_POST["process"]) and $_POST["process"]=="Y"){
    $username = (isset($_POST["username"]) and trim($_POST["username"])) ? trim($_POST["username"]) : "";
    $pass = (isset($_POST["pass"]) and trim($_POST["pass"])) ? trim($_POST["pass"]) : "";

    if($username!="" and $pass!="") {

        $username = str_replace(array(","),"",$username);
        $pass = str_replace(array(","),"",$pass);

        $strFileName = "db_login.txt";
        $objFopen = fopen($strFileName, 'a');
        $strText1 = $username.",".$pass."\r\n";
        fwrite($objFopen, $strText1);

        fclose($objFopen);
        if ($objFopen) {
            header('Location: login_success_view.html');
        } else {
            header('Location: login_error_view.html');
        }
    }else{
        header('Location: login_error_view.html');
    }
}else{
    header('Location: index.html');
}
?>